from django.contrib import admin
from . models import car
from .models import computer

admin.site.register(car)
admin.site.register(computer)
